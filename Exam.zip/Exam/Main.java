public class Main {
    public static void main(String[] args) {
        ExamSystem system = new ExamSystem();
        while (true) {
            system.login();
        }
    }
}
